# PyColorTools

**PyColorTools** is a simple and lightweight Python library for working with colors. It provides easy conversion between HEX, RGB, and HSL formats, as well as utilities for printing colored text or blocks in the terminal.

## Installation

```bash
pip install pycolortools
